package sample;

public class CurrencyConverter
{
    public double Yen;

    public double EuroToYen (double euro)
    {
        Yen = euro * 124;
        return Yen;
    }
}
